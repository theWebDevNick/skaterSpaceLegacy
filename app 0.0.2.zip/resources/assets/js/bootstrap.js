/**
 * Created by nick on 2/25/17.
 */
require('bootstrap-sass/assets/javascripts/bootstrap');
require('mdbootstrap/js/tether.min.js');
require('mdbootstrap/js/mdb.min.js');
