@extends('layouts.mdApp')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6">

                <!--Card-->
                <div class="card">

                    <!--Card image-->
                    <div class="view overlay hm-white-slight">
                        <img src="https://mdbootstrap.com/images/reg/reg%20(2).jpg" class="img-fluid" alt="">
                        <a>
                            <div class="mask"></div>
                        </a>
                    </div>
                    <!--/.Card image-->

                    <!--Card content-->
                    <div class="card-block">
                        <!--Title-->
                        <h4 class="card-title">Card title</h4>
                        <!--Text-->
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a class="btn btn-primary">Button</a>
                    </div>
                    <!--/.Card content-->

                </div>
                <!--/.Card-->

            </div>
        </div>
    </div>
    <!--/Start your project here-->
@endsection