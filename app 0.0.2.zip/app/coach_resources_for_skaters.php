<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class coach_resources_for_skaters extends Model
{
    //
}
