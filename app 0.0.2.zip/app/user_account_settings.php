<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class user_account_settings extends Model
{
    //
}
