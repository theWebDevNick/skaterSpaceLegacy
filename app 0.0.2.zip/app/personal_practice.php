<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class personal_practice extends Model
{
    //
}
