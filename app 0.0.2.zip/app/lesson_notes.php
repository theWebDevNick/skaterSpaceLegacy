<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lesson_notes extends Model
{
    //
}
