<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skater_completed_skills extends Model
{
    //
}
