<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class coach_skater_relationships extends Model
{
    //
}
