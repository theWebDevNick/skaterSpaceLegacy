<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skating_disciplines extends Model
{
    //
    protected $hidden = array('pivot','created_at','updated_at','is_active');
}
