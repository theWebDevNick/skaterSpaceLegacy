<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class message_threads extends Model
{
    //
}
