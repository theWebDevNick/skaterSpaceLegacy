<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class governing_organizations extends Model
{
    //
}
