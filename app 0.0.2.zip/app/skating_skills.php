<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skating_skills extends Model
{
    protected $hidden = array('pivot');
    //
}
