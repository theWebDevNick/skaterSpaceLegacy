<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skating_clubs extends Model
{
    //
}
