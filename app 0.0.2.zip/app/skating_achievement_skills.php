<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skating_achievement_skills extends Model
{
    //
}
