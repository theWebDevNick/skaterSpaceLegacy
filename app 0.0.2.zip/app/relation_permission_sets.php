<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class relation_permission_sets extends Model
{
    //
}
