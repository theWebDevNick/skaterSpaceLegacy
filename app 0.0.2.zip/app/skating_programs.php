<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skating_programs extends Model
{
    //
}
