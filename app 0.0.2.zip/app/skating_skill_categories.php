<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class skating_skill_categories extends Model
{
    //
}
